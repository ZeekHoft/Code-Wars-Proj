from run import print_action

def main():
    print_action()



if __name__ == "main":
    main()



     